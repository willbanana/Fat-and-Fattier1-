Description:
    Tileset of a large boulder/rock. Sheets for 32px and 16px tiles.
    
    Originally created for Stendhal: http://stendhalgame.org/

Copyright � 2013 Jordan Irwin (a.k.a. AntumDeluge)

This work can be distributed under the terms and conditions of one of the following included licenses:

� Creative Commons Attribution 3.0 (or later):
    See License-CC-BY-3.0.txt

� BSD-style:
    See License-BSD.txt

� MIT-style:
    See License-MIT.txt
